<?php

header("Location: labwork.php");

?>